return {
  "nvim-lua/plenary.nvim", -- used by many plugins
  "christoomey/vim-tmux-navigator", -- tmux & split window navigation
}

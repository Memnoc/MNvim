return {
  "mrcjkb/rustaceanvim",
  version = "^4",
  ft = { "rust" },
}
